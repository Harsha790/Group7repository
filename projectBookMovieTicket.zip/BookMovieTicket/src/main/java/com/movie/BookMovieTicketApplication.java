package com.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMovieTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMovieTicketApplication.class, args);
	}

}
