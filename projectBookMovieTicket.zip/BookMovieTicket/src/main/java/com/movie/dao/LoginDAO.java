package com.movie.dao;


	import org.springframework.data.repository.CrudRepository;

import com.movie.bean.LoginBean;

	public interface LoginDAO extends CrudRepository<LoginBean, String>{

	}