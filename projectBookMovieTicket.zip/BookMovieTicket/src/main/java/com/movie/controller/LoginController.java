package com.movie.controller;

	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.servlet.ModelAndView;

	import com.movie.bean.LoginBean;
import com.movie.dao.LoginDAO;

	@Controller
	public class LoginController {
		
		@Autowired
		LoginDAO dao;
		
		@RequestMapping("Start")
		public ModelAndView callLandingPage() 
		{
			ModelAndView mv = new ModelAndView();
			mv.setViewName("Landing");
			return mv;
		}
		@RequestMapping("Welcome")
		public ModelAndView callWelcome()
		{
			ModelAndView mv = new ModelAndView();
			mv.setViewName("Welcome");
			return mv;
		}
		@RequestMapping("signup")
		public ModelAndView callsignup() {
			ModelAndView mv = new ModelAndView();
			mv.setViewName("signup");
			return mv;
		}
		
		@RequestMapping("LoginPage")
		public ModelAndView callLoginPage() 
		{
			ModelAndView mv = new ModelAndView();
			mv.setViewName("Login");
			return mv;
		}
		@RequestMapping("Signup")
		public ModelAndView signup(LoginBean login) {
			ModelAndView mv = new ModelAndView();
			dao.save(login);
			mv.setViewName("Login");
			mv.addObject("msg", "Signup Successfuly");
			return mv;
		}
		
		@RequestMapping("Login")
		public ModelAndView login(LoginBean login) {
			ModelAndView mv = new ModelAndView();
			LoginBean tmp = dao.findById(login.getUsername()).get();
			if(tmp.getPassword().equals(login.getPassword())) {
			   mv.setViewName("LoginSuccess");
			}
			else {
				mv.setViewName("Login");
				mv.addObject("msg", "LoginFailed");
			}
			
			return mv;
		}
	
		
	@RequestMapping("Book")
			public ModelAndView callBookPage() 
			{
				ModelAndView mv = new ModelAndView();
				mv.setViewName("Book");
				return mv;
}
			@RequestMapping("DashBoard")
			public ModelAndView callDashboardPage() 
			{
				ModelAndView mv = new ModelAndView();
				mv.setViewName("DashBoard");
				return mv;
}
			@RequestMapping("Contact Us")
			public ModelAndView callContactPage() 
			{
				ModelAndView mv = new ModelAndView();
				mv.setViewName("Contact Us");
				return mv;
			}
			@RequestMapping("About Us")
			public ModelAndView callAboutPage() 
			{
				ModelAndView mv = new ModelAndView();
				mv.setViewName("About Us");
				return mv;
			}
			@RequestMapping("Feedback")
			public ModelAndView callFeedbackPage() 
			{
				ModelAndView mv = new ModelAndView();
				mv.setViewName("Feedback");
				return mv;
			}
			@RequestMapping("finish")
			public ModelAndView callfinish() 
			{
				ModelAndView mv = new ModelAndView();
				mv.setViewName("finish.jsp");
				return mv;

	}
	}
